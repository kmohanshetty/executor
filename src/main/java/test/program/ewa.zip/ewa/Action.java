package test.program.ewa;

public interface Action {
	Long execute(GrLeadTime gr);
}
